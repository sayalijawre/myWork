import React, { Component } from 'react';
import './App.css';

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = { uname: '', inputUname: '', email: '', inputEmail: '', mobile: '', inputMob: '', address: '', inputAdd: '', purpose: '', inputPurpose: '', date: '', inputDate: '', mode: 'edit' };

    this.handleChangeUname = this.handleChangeUname.bind(this);
    this.handleChangeEmail = this.handleChangeEmail.bind(this);
    this.handleChangeMob = this.handleChangeMob.bind(this);
    this.handleChangeAdd = this.handleChangeAdd.bind(this);
    this.handleChangePurpose = this.handleChangePurpose.bind(this);
    this.handleChangeDate = this.handleChangeDate.bind(this);
    this.handleSave = this.handleSave.bind(this);
    this.handleEdit = this.handleEdit.bind(this);
  }

  handleChangeUname(e) {
    this.setState({ inputUname: e.target.value });
  }
  handleChangeEmail(e) {
    this.setState({ inputEmail: e.target.value });
  }
  handleChangeMob(e) {
    this.setState({ inputMob: e.target.value });
  }
  handleChangeAdd(e) {
    this.setState({ inputAdd: e.target.value });
  }
  handleChangePurpose(e) {
    this.setState({ inputPurpose: e.target.value });
  }
  handleChangeDate(e) {
    this.setState({ inputDate: e.target.value });
  }

  handleSave() {
    this.setState({
      uname: this.state.inputUname, inputUname: '', email: this.state.inputEmail, inputEmail: '', mobile: this.state.inputMob, inputMob: '', address: this.state.inputAdd, inputAdd: '', purpose: this.state.inputPurpose, inputPurpose: '', date: this.state.inputDate, inputDate: '', mode: 'view'
    });
  }

  handleEdit() {
    this.setState({ mode: 'edit' });
  }

  render() {
    if (this.state.mode === 'view') {
      return (

        <div class='container'>

          <link href="bootstrap-3.2.0-dist/css/bootstrap.min.css" rel="stylesheet" />
          <link href="bootstrap-3.2.0-dist/css/bootstrap-theme.min.css" rel="stylesheet" />
          <h4>Customers visit Information</h4>
          <div class="jumbrotron">
            <div id="div1">


              <p> &nbsp;&nbsp;Name: {this.state.uname} </p>
              <p> &nbsp;&nbsp;Email Id: {this.state.email} </p>
              <p> &nbsp;&nbsp;Mobile Number: {this.state.mobile} </p>
              <p> &nbsp;&nbsp;Address: {this.state.address} </p>
              <p> &nbsp;&nbsp;Discription/Purpose: {this.state.purpose} </p>
              <p> &nbsp;&nbsp;Date of Visit: {this.state.date} </p>

              &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;
              <button onClick={this.handleEdit} class='btn btn-danger'> Delete</button>
            </div>
            <script src="jQuery/jQuery-1.11.1.min.js" />
            <script src="bootstrap-3.2.0-dist/js/bootstrap.min.js" />
          </div>
        </div>
      );
    }
    else {
      return (

        <div align="center" class='container'>

          <link href="bootstrap-3.2.0-dist/css/bootstrap.min.css" rel="stylesheet" />
          <link href="bootstrap-3.2.0-dist/css/bootstrap-theme.min.css" rel="stylesheet" />
          <div class="jumbrotron">

            <h4>Customer Registration form</h4>
            <form class="form-inline">

              <input onChange={this.handleChangeUname} value={this.state.inputUname} placeholder="Username" /><br /><br />
              <input onChange={this.handleChangeEmail} value={this.state.inputEmail} placeholder="Email id" /><br /><br />
              <input onChange={this.handleChangeMob} value={this.state.inputMob} placeholder="Mobile Number" /><br /><br />
              <input onChange={this.handleChangeAdd} value={this.state.inputAdd} placeholder="Address" /><br /><br />
              <input onChange={this.handleChangePurpose} value={this.state.inputPurpose} placeholder="Purpose of visit" /><br /><br />
              <input onChange={this.handleChangeDate} value={this.state.inputDate} placeholder="date Of Visit" /><br /><br />

              <button onClick={this.handleSave} class="btn btn-success"> Login </button>
            </form>
            <script src="jQuery/jQuery-1.11.1.min.js" />
            <script src="bootstrap-3.2.0-dist/js/bootstrap.min.js" />
          </div></div>
      );
    }
  }
}

export default App;
