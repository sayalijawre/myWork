For execution of urls, used postman.
All the operation's data has been hard coded.
Range of price has been mentioned in the code.
Updating mobile name for a specific mobile Id is also given in the code.
New mobile data is also provided in the code itself.