import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';



@Component({
  selector: 'app-login',
    templateUrl: './login-page.component.html',
    styleUrls: ['./login-page.component.css']
  
})

export class LoginPageComponent implements OnInit {
   username:string;
   password:string;
   
    constructor(private route:Router) { }
    bgSrc='assets/image/bgImage.jpg'
    ngOnInit() {

    }

    LoginUser() {
       if(this.username=="Admin" && this.password=="admin")
       {
         this.route.navigate(['/welcome']);
       }
       else{
         alert("Invalid UserName or Password");
       }
    }
}
