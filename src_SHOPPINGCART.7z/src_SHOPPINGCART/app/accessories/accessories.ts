export interface IAccessories {
    id: number;
    product:string;
    discount:string;
    price: number;
    description: string;
    imageUrl: string;
   
  

}