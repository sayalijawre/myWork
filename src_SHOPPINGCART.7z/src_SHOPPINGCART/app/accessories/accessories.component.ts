import { Component, OnInit } from '@angular/core';
import {IAccessories} from './accessories';
import {ProductService} from '../product.service'

@Component({
  selector: 'app-accessories',
  templateUrl: './accessories.component.html',
  styleUrls: ['./accessories.component.css']
})
export class AccessoriesComponent implements OnInit {
  pageTitle="Accessories List";
  Accessory:IAccessories[];
  imageWidth:number=200;
  imageHeight:number=150;
  cartProductsId:number[];
  constructor(private productService:ProductService) { }
  getAccessories():void{
    this.Accessory=this.productService.getAccessories();
    this.cartProductsId=this.productService.getCartProductsId();
  }
  ngOnInit() {
    this.getAccessories();
  }
  addToCart(proid,proName,proPrice,proImage){
  sessionStorage.setItem('id',proid);
  sessionStorage.setItem('product',proName);
  sessionStorage.setItem('price',proPrice);
  sessionStorage.setItem('image',proImage);
  this.productService.addProduct();
  this.cartProductsId=this.productService.getCartProductsId();
}
removeFromCart(proid){
  this.productService.removeProduct(proid);
  this.cartProductsId=this.productService.getCartProductsId();
}
}
