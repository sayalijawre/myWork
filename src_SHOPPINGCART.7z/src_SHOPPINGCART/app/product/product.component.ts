import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  startShopping:boolean=false;
  productCategory:string[]=["Electronics","Clothing","Grocery","Stationary","Accessories"];
  selectedCategory:string="Electronics";
  
  title = 'CapG Shopping Cart';

  constructor(private route:Router) { }
  ngOnInit() {
  }

  loadProducts():void{
    this.startShopping=true;
  }

  onSelect(category:string):void{
    this.selectedCategory=category;
  }

  loadCart():void
  {
    this.route.navigate(['/cart']);
  }

  logOut():void{
    this.route.navigate(['/']);
  }
}
