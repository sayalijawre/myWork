import { IElectronic } from '../electronics/electronics';

export const ELECTRONICS: IElectronic[] = [
  { id: 2221, product: 'Television', price:270, discount:'20 %',description:'Sony 80cm 32 inch HD ready LED TV',imageUrl:'https://images.pexels.com/photos/987586/pexels-photo-987586.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940'},
  { id: 2222, product: 'Laptop', price:340, discount:'15 %',description:'Dell inspiron core i7',imageUrl:'https://images.pexels.com/photos/597331/pexels-photo-597331.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940' },
  { id: 2223, product: 'Mobile', price:250, discount:'15 %',
  description: 'Asus Zenfone Max',imageUrl:'https://images.pexels.com/photos/248528/pexels-photo-248528.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940g' }
]




